
// Smooth anchor scroll
document.addEventListener('click', (e)=>{
  const a = e.target.closest('a[href^="#"]');
  if(a){
    const id = a.getAttribute('href').slice(1);
    const el = document.getElementById(id);
    if(el){
      e.preventDefault();
      el.scrollIntoView({behavior:'smooth', block:'start'});
    }
  }
});

// Booking form -> open mailto with structured body (no backend required)
(function(){
  const form = document.getElementById('bookingForm');
  if(!form) return;
  const status = document.getElementById('status');

  form.addEventListener('submit', function(e){
    if (form.getAttribute('action')) { return; }
    e.preventDefault();
    status.textContent = '';

    const required = ['vorname','nachname','einrichtung','email','telefon','einsatzort','beginn'];
    for(const id of required){
      const inp = document.getElementById(id);
      if(!inp || !inp.value.trim()){
        status.textContent = 'Bitte füllen Sie alle Pflichtfelder aus.';
        status.style.color = '#d64545';
        inp && inp.focus();
        return;
      }
    }
    const schichten = Array.from(document.querySelectorAll('input[name="schicht"]:checked')).map(i=>i.value).join(', ');
    const payload = {
      Vorname: form.vorname.value,
      Nachname: form.nachname.value,
      Einrichtung: form.einrichtung.value,
      Rolle: form.rolle.value || '-',
      Email: form.email.value,
      Telefon: form.telefon.value,
      Einsatzort: form.einsatzort.value,
      Beginn: form.beginn.value,
      Ende: form.ende.value || '-',
      Schicht: schichten || '-',
      Budget: form.honorar.value || '-',
      Nachricht: form.nachricht.value || '-'
    };

    const subject = encodeURIComponent('Buchungsanfrage – ' + payload.Einrichtung + ' (' + payload.Beginn + ')');
    const body = encodeURIComponent(
      'Buchungsanfrage\n\n' +
      Object.entries(payload).map(([k,v])=>`${k}: ${v}`).join('\n')
    );

    // Change target email address here if needed
    const to = 'fachkraft@bordea-pflege.de';

    const href = `mailto:${to}?subject=${subject}&body=${body}`;
    status.textContent = 'E-Mail-Programm wird geöffnet …';
    status.style.color = '#0aa06f';

    // Open mail client
    window.location.href = href;
  });
})();
